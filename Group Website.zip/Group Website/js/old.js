<script type="module">
  // Import the functions you need from the SDKs you need
  import { initializeApp } from "https://www.gstatic.com/firebasejs/12.11.0/firebase-app.js";
  import { getAnalytics } from "https://www.gstatic.com/firebasejs/12.11.0/firebase-analytics.js";
  // TODO: Add SDKs for Firebase products that you want to use
  // https://firebase.google.com/docs/web/setup#available-libraries

  // Your web app's Firebase configuration
  // For Firebase JS SDK v7.20.0 and later, measurementId is optional
  const firebaseConfig = {
    apiKey: "AIzaSyDzecOtJM9gy7xU_KoAEQ59uib2ubM4tE4",
    authDomain: "abdevillors.firebaseapp.com",
    databaseURL: "https://abdevillors-default-rtdb.asia-southeast1.firebasedatabase.app",
    projectId: "abdevillors",
    storageBucket: "abdevillors.firebasestorage.app",
    messagingSenderId: "683003813250",
    appId: "1:683003813250:web:b1249142c849a56eff439b",
    measurementId: "G-2NL6G5RRS5"
  };

  // Initialize Firebase
  const app = initializeApp(firebaseConfig);
  const analytics = getAnalytics(app);
</script>